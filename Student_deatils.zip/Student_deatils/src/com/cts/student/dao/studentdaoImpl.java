package com.cts.student.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cts.student.student;
import com.cts.student.util.dbconset;
import com.cts.student.util.dbconstants;

public class studentdaoImpl  implements studentdao{
	
	public boolean insert_student(student s)
	{
		Connection con=null;
		PreparedStatement pst=null;
		boolean b=false;
		
		
		try {
			con=dbconset.getConnection(dbconstants.DRIVER, dbconstants.URL, dbconstants.UNAME, dbconstants.PWD);
			pst=con.prepareStatement("insert into studentinfo(Rollno,Name,Address) values (?,?,?)");
			pst.setInt(1, s.getRollno());
			pst.setString(2, s.getName());
			pst.setString(3, s.getAddress());
			int r=pst.executeUpdate();
			con.close();
			if(r>0)
				b=true;
			else
				b=false;
		} 
		catch (Exception e) {
			if(con!=null)
			{
				try {
					con.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}

		}
		
		return b;
		
	}

}
