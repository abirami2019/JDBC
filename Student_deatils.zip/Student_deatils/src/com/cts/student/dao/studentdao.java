package com.cts.student.dao;

import com.cts.student.student;

public interface studentdao {
	public boolean insert_student(student s);

}
