package com.cts.student;

public class student {
		private int Rollno;
		private String Name;
		private String Address;
		public student()
		{
			
		}
		public student(int rollno, String name, String address) {
			super();
			Rollno = rollno;
			Name = name;
			Address = address;
		}
		public int getRollno() {
			return Rollno;
		}
		public void setRollno(int rollno) {
			Rollno = rollno;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		

}
