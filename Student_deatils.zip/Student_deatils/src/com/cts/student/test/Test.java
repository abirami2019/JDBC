package com.cts.student.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cts.student.student;
import com.cts.student.dao.studentdao;
import com.cts.student.dao.studentdaoImpl;

public class Test {

	public static void main(String[] args) throws NumberFormatException, IOException {
		studentdao dao=new studentdaoImpl();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the student details");
		int Rollno=Integer.parseInt(br.readLine());
		String Name=br.readLine();
		String Address=br.readLine();
		student s=new student(Rollno,Name,Address);
		boolean b=dao.insert_student(s);
		if(b)
			System.out.println("inserted");
		else
			System.out.println("not inserted");
	}

}
